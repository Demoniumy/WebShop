<?php
/* Smarty version 4.5.5, created on 2025-04-07 01:36:03
  from 'C:\xampp\htdocs\WebShop\smarty\templates\warenkorb.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_67f30fe310cbd4_51583502',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd084d0030f3c30db42dbf73b273d728e80b87619' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WebShop\\smarty\\templates\\warenkorb.tpl',
      1 => 1743982561,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_67f30fe310cbd4_51583502 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warenkorb</title>
    <link rel="stylesheet" href="CSS/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="CSS/warenkorb.css">
</head>
<body>
    <header>
        <p>Shop Name</p>
        <form>
            <input type="text" placeholder="Suche...">
        </form>
        <button id="cart-button">Warenkorb</button>
    </header>

    <main class="cart-page">
        <h2>Dein Warenkorb</h2>
        
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['warenkorb']->value, 'ware');
$_smarty_tpl->tpl_vars['ware']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['ware']->value) {
$_smarty_tpl->tpl_vars['ware']->do_else = false;
?>
            <?php if ($_smarty_tpl->tpl_vars['kunde']->value == $_smarty_tpl->tpl_vars['ware']->value['ID_Kunde']) {?>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['produkte']->value, 'pro');
$_smarty_tpl->tpl_vars['pro']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['pro']->value) {
$_smarty_tpl->tpl_vars['pro']->do_else = false;
?>
                    <?php if ($_smarty_tpl->tpl_vars['ware']->value['ID_Kunde'] == $_smarty_tpl->tpl_vars['pro']->value['ID_Produkt']) {?>
                        <div class="cart-item">
                            <img src="Bilder/<?php echo $_smarty_tpl->tpl_vars['pro']->value['Bild'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['pro']->value['Name'];?>
">
                            <div class="cart-item-info">
                                <h2><?php echo $_smarty_tpl->tpl_vars['pro']->value['Name'];?>
</h2>
                                <p><?php echo $_smarty_tpl->tpl_vars['pro']->value['Preis'];?>
€</p>
                            </div>
                            <div class="cart-item-quantity">
                                <i class="fa fa-minus"></i>
                                <p><?php echo $_smarty_tpl->tpl_vars['ware']->value['Anzahl'];?>
</p>
                                <i class="fa fa-plus"></i>
                            </div>
                        </div>
                    <?php }?>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            <?php }?>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

    </main>
    
        <?php echo '<script'; ?>
>
            const minusButtons = document.querySelectorAll('.fa-minus');
            const plusButtons = document.querySelectorAll('.fa-plus');

            minusButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const mengeElement = this.nextElementSibling; // Menge-Element
                    const produktId = this.closest('.cart-item').dataset.produktId; // ID des Produkts
                    let aktuelleMenge = parseInt(mengeElement.innerText);

                    if (aktuelleMenge > 1) {
                        // Reduzieren der Menge
                        const neueMenge = aktuelleMenge - 1;
                        mengeElement.innerText = neueMenge;
                        
                        // Senden der Änderung an den Server via fetch
                        fetch('anzahl.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: `produkt_id=${produktId}&menge=${neueMenge}`
                        })
                        .then(response => response.json())
                        .then(daten => {
                            if (daten.erfolg) {
                                console.log('Menge erfolgreich geändert');
                            } else {
                                console.error('Fehler bei der Mengenänderung');
                                mengeElement.innerText = aktuelleMenge; // Rückgängig machen der Änderung, falls Fehler
                            }
                        });
                    }
                });
            });

            plusButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const mengeElement = this.previousElementSibling; // Menge-Element
                    const produktId = this.closest('.cart-item').dataset.produktId; // ID des Produkts
                    let aktuelleMenge = parseInt(mengeElement.innerText);
                    const neueMenge = aktuelleMenge + 1;
                    mengeElement.innerText = neueMenge;
                   alert(produktId);
                    fetch('anzahl.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'produkt_id=' + produktId + '&menge=' + neueMenge
                    })
                    .then(response => response.json())
                    .then(daten => {
                        if (daten.erfolg) {
                            console.log('Menge erfolgreich geändert');
                        } else {
                            console.error('Fehler bei der Mengenänderung');
                            mengeElement.innerText = aktuelleMenge; // Rückgängig machen der Änderung, falls Fehler
                        }
                    });
                });
            });
        <?php echo '</script'; ?>
>
    
</body>
</html>
<?php }
}

<?php

require 'defauld.inc.php';

// POST-Daten erhalten
$produktId = isset($_POST['produkt_id']) ? $_POST['produkt_id'] : null;
$menge = isset($_POST['menge']) ? $_POST['menge'] : null;

if ($produktId && $menge !== null) {

    $sql = "UPDATE warenkorb SET Anzahl = :new WHERE ID_Produkt = :id;";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(":new", $menge);
    $stmt->bindParam(":id", $produktId);

    
    if ($stmt->execute()) {
        echo json_encode(['erfolg' => true]);
    } else {
        echo json_encode(['erfolg' => false, 'nachricht' => 'Fehler beim Aktualisieren']);
    }

    $stmt->closeCursor();
} else {
    echo json_encode(['erfolg' => false, 'nachricht' => 'Ungültige Eingabedaten']);
}


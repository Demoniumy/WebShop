-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 02. Feb 2025 um 20:29
-- Server-Version: 10.4.32-MariaDB
-- PHP-Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `webshop`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `betrift`
--

CREATE TABLE `betrift` (
  `ID_Rechnung` int(11) NOT NULL,
  `ID_Produkt` int(11) NOT NULL,
  `Anzahl` int(11) NOT NULL,
  `Kaufpreis` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hersteller`
--

CREATE TABLE `hersteller` (
  `ID_Hersteller` bigint(20) UNSIGNED NOT NULL,
  `Webadresse` text DEFAULT NULL,
  `Name` text DEFAULT NULL,
  `Email` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `hersteller`
--

INSERT INTO `hersteller` (`ID_Hersteller`, `Webadresse`, `Name`, `Email`) VALUES
(1, 'www.hp.de', 'Hewlett Packard', 'info@hp.de'),
(2, 'www.siemens.de', 'Siemens', 'support@siemens.de'),
(3, 'www.medion.de', 'Medion', 'support@medion.de');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kunde`
--

CREATE TABLE `kunde` (
  `ID_Kunde` bigint(20) UNSIGNED NOT NULL,
  `Kennung` text NOT NULL,
  `Vorname` text NOT NULL,
  `Nachname` text NOT NULL,
  `Straße` text NOT NULL,
  `PLZ` int(11) NOT NULL,
  `Ort` text NOT NULL,
  `Kontonummer` int(11) NOT NULL,
  `BLZ` text NOT NULL,
  `Institut` text NOT NULL,
  `Passwort` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `kunde`
--

INSERT INTO `kunde` (`ID_Kunde`, `Kennung`, `Vorname`, `Nachname`, `Straße`, `PLZ`, `Ort`, `Kontonummer`, `BLZ`, `Institut`, `Passwort`) VALUES
(1, 'test', 'Test', 'Test', 'Test', 12, '21', 231, '12', '13', 'test');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `produkte`
--

CREATE TABLE `produkte` (
  `ID_Produkt` bigint(20) UNSIGNED NOT NULL,
  `Name` text DEFAULT NULL,
  `Beschreibung` text DEFAULT NULL,
  `Preis` float DEFAULT NULL,
  `Hersteller` int(11) NOT NULL,
  `Produktkategorie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `produkte`
--

INSERT INTO `produkte` (`ID_Produkt`, `Name`, `Beschreibung`, `Preis`, `Hersteller`, `Produktkategorie`) VALUES
(1, 'HP ScanJet3300C', 'Flachbettscanner', 99, 1, 1),
(2, 'HP ScanJet 2220A', 'Flachbettscanner', 56, 1, 1),
(3, 'HP LaserJet 3477C', 'Laserdrucker', 299, 1, 3),
(4, 'HP LaserJet 7769C', 'Farblaserdrucker', 1590, 1, 3),
(5, 'MD 1772 JC', 'Monitor', 150, 3, 2),
(6, 'MD 6155 AH', '17 Zoll TFT Bildschirm', 350, 3, 2),
(7, 'MD 1334 S', 'Flachbettscanner', 65, 3, 1),
(8, 'MD 2443 S ', 'Flachbettscanner', 76, 3, 1),
(9, 'SI 1221 C', '19 Zoll Monitor', 200, 2, 2),
(10, 'SI 7822 TFT', '21 Zoll TFT-Monitor ', 569, 2, 2),
(11, 'SI P 3244', 'DIN A1 Plotter', 1590, 2, 4),
(12, 'SI D1121 C ', 'Farblaserdrucker', 547, 2, 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `produktkategorie`
--

CREATE TABLE `produktkategorie` (
  `ID_Produktkategorie` bigint(20) UNSIGNED NOT NULL,
  `Beschreibung` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `produktkategorie`
--

INSERT INTO `produktkategorie` (`ID_Produktkategorie`, `Beschreibung`) VALUES
(1, 'Scanner'),
(2, 'Monitore'),
(3, 'Drucker'),
(4, 'Plotter');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rechnung`
--

CREATE TABLE `rechnung` (
  `ID_Rechnung` bigint(20) UNSIGNED NOT NULL,
  `Datum` date NOT NULL,
  `Uhrzeit` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wählt`
--

CREATE TABLE `warenkorb` (
  `ID_Kunde` int(11) NOT NULL,
  `ID_Produkt` int(11) NOT NULL,
  `Anzahl` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `hersteller`
--
ALTER TABLE `hersteller`
  ADD UNIQUE KEY `ID_Hersteller` (`ID_Hersteller`);

--
-- Indizes für die Tabelle `kunde`
--
ALTER TABLE `kunde`
  ADD UNIQUE KEY `ID_Kunde` (`ID_Kunde`);

--
-- Indizes für die Tabelle `produkte`
--
ALTER TABLE `produkte`
  ADD UNIQUE KEY `ID_Produkt` (`ID_Produkt`);

--
-- Indizes für die Tabelle `produktkategorie`
--
ALTER TABLE `produktkategorie`
  ADD UNIQUE KEY `ID_Produktkategorie` (`ID_Produktkategorie`);

--
-- Indizes für die Tabelle `rechnung`
--
ALTER TABLE `rechnung`
  ADD UNIQUE KEY `ID_Rechnung` (`ID_Rechnung`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `hersteller`
--
ALTER TABLE `hersteller`
  MODIFY `ID_Hersteller` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `kunde`
--
ALTER TABLE `kunde`
  MODIFY `ID_Kunde` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `produkte`
--
ALTER TABLE `produkte`
  MODIFY `ID_Produkt` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT für Tabelle `produktkategorie`
--
ALTER TABLE `produktkategorie`
  MODIFY `ID_Produktkategorie` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `rechnung`
--
ALTER TABLE `rechnung`
  MODIFY `ID_Rechnung` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

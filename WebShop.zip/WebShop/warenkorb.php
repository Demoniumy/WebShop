<?php

require 'defauld.inc.php';

$sql="SELECT * FROM produkte";
$stmt=$db->prepare($sql);
$stmt->execute();
$produkte=$stmt->fetchAll();

$sql="SELECT * FROM warenkorb";
$stmt=$db->prepare($sql);
$stmt->execute();
$warenkorb=$stmt->fetchAll();

if(isset($_SESSION['ID_Kunde']))
{
    $kunde=$_SESSION['ID_Kunde'];
}else
{
    $kunde=NULL;    
}


$smarty->assign('warenkorb',$warenkorb);
$smarty->assign('kunde',$kunde);
$smarty->assign('produkte',$produkte);
$smarty->display('warenkorb.tpl');
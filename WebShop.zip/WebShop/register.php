<?php

require 'defauld.inc.php';
$error=NULL;

if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
    $kennung = $_POST['kennung'];
    $vorname = $_POST['vorname'];
    $nachname = $_POST['nachname'];
    $email = $_POST['email'];
    $password = trim($_POST['password']);
    $passwordvery=trim($_POST['passwordvery']);

    if(strlen($password)>=8)
    {
        if($password==$passwordvery)
        {
            $password=password_hash($password,PASSWORD_DEFAULT);
            $sql="INSERT INTO Kunde (Kennung,Vorname,Nachname,Passwort,Email) VALUES (:ken,:vor,:nach,:pw,:email)";
            $stmt=$db->prepare($sql);
            $stmt->bindParam(":ken",$kennung);
            $stmt->bindParam(":vor",$vorname);
            $stmt->bindParam(":nach",$nachname);
            $stmt->bindParam(":pw",$password);
            $stmt->bindParam(":email",$email);
            $stmt->execute();

            header("location:login.php"); 

        }else
        {
            $error="Passwort stimmt nicht über ein";
        }
    }else
    {
        $error="Passwort muss mindestens 8 Zeichen lang sein";
    }


}

$smarty->assign('error', $error);
$smarty->display('register.tpl');

<?php

require 'defauld.inc.php';
session_destroy(); 
header("location:index.php"); 
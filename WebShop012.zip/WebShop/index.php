<?php

require 'defauld.inc.php';

//$smarty->testInstall();
$sql="SELECT * FROM produkte";
$stmt=$db->prepare($sql);
$stmt->execute();
$produkte=$stmt->fetchAll();

if(isset($_SESSION['ID_Kunde']))
{
    $kunde=$_SESSION['ID_Kunde'];

    $sql="SELECT * FROM produkte p LEFT JOIN warenkorb w ON p.ID_Produkt=w.ID_Produkt WHERE w.ID_Kunde = :id";
    $stmt=$db->prepare($sql);
    $stmt->bindParam("id",$kunde);
    $stmt->execute();
    $warenkorb=$stmt->fetchAll();
}else
{
    $kunde=NULL;    
}

$smarty->assign('warenkorb',$warenkorb);
$smarty->assign('kunde',$kunde);
$smarty->assign('produkte',$produkte);
$smarty->display('index.tpl');


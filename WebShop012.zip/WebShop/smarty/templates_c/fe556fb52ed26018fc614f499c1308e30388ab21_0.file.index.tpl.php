<?php
/* Smarty version 4.5.5, created on 2025-04-29 22:14:55
  from 'C:\xampp\htdocs\WebShop\smarty\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_6811333f64c5a7_20608986',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fe556fb52ed26018fc614f499c1308e30388ab21' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WebShop\\smarty\\templates\\index.tpl',
      1 => 1745957145,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:head.inc.tpl' => 1,
  ),
),false)) {
function content_6811333f64c5a7_20608986 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
    <title>WebShop</title>
    <?php $_smarty_tpl->_subTemplateRender("file:head.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <link rel="stylesheet" href="CSS/main.css">
</head>
<body>

<header>
    <p onclick="window.location.href='index.php'">WebshopName</p>

    <form action="suche.php" method="POST">
        <input type="text" name="suche" placeholder="Suche...">
    </form>

    <?php if (!(isset($_smarty_tpl->tpl_vars['kunde']->value))) {?>
        <i class="fa fa-sign-in" onclick="window.location.href='login.php'"></i>
    <?php } else { ?>
        <i class="fa fa-sign-out" onclick="window.location.href='logout.php'"></i>
    <?php }?>

    <button>
        <i class="fa fa-shopping-basket" onclick="warenkorb()"></i>
    </button>
</header>

<main>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['produkte']->value, 'pro');
$_smarty_tpl->tpl_vars['pro']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['pro']->value) {
$_smarty_tpl->tpl_vars['pro']->do_else = false;
?>
        <div class="produkt">
            <img src="Bilder/<?php echo $_smarty_tpl->tpl_vars['pro']->value['Bild'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['pro']->value['Name'];?>
" onclick="window.location.href='anzeige.php?id=<?php echo $_smarty_tpl->tpl_vars['pro']->value['ID_Produkt'];?>
'">
            <div class="produkt-info">
                <h2 onclick="window.location.href='anzeige.php?id=<?php echo $_smarty_tpl->tpl_vars['pro']->value['ID_Produkt'];?>
'"><?php echo $_smarty_tpl->tpl_vars['pro']->value['Name'];?>
</h2>
                <h3><?php echo $_smarty_tpl->tpl_vars['pro']->value['Preis'];?>
€</h3>
                <div class="button-wrapper">
                    <button <?php if ((isset($_smarty_tpl->tpl_vars['kunde']->value))) {?>onclick="window.location.href='warenkorbAdd.php?pro=<?php echo $_smarty_tpl->tpl_vars['pro']->value['ID_Produkt'];?>
'"<?php } else { ?>onclick="anmelden()"<?php }?>>In den Warenkorb</button>
                </div>
            </div>
        </div>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</main>

<div id="warenkorb">
    <i class="fa fa-times" onclick="warenkorb()"></i>
    <h2>Warenkorb</h2>
    <?php if (!(isset($_smarty_tpl->tpl_vars['kunde']->value))) {?>
        <p>Bitte Anmelden</p>
    <?php } else { ?>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['warenkorb']->value, 'ware');
$_smarty_tpl->tpl_vars['ware']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['ware']->value) {
$_smarty_tpl->tpl_vars['ware']->do_else = false;
?>
            <div>
                <img src="Bilder/<?php echo $_smarty_tpl->tpl_vars['ware']->value['Bild'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['ware']->value['Name'];?>
">
                <h2><?php echo $_smarty_tpl->tpl_vars['ware']->value['Name'];?>
</h2>
                <p><?php echo $_smarty_tpl->tpl_vars['ware']->value['Anzahl'];?>
</p>
            </div>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    <?php }?>
    <button onclick="window.location.href='warenkorb.php'" class="wbutton">Warenkorb</button>
</div>


<?php echo '<script'; ?>
>
    function warenkorb() {
        const panel = document.getElementById('warenkorb');
        panel.style.display = (panel.style.display === 'block') ? 'none' : 'block';
    }

    function anmelden() {
        alert("Bitte anmelden");
    }
<?php echo '</script'; ?>
>


</body>
</html>
<?php }
}

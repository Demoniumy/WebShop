<?php
/* Smarty version 4.5.5, created on 2025-04-29 22:50:15
  from 'C:\xampp\htdocs\WebShop\smarty\templates\kauf.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_68113b8734c136_66249317',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '72aa7b0f82e4be1eb8ddf1f14ac2a335bc6a8a63' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WebShop\\smarty\\templates\\kauf.tpl',
      1 => 1745959813,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:head.inc.tpl' => 1,
  ),
),false)) {
function content_68113b8734c136_66249317 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="de">
<head>
    <?php $_smarty_tpl->_subTemplateRender("file:head.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <?php echo '<script'; ?>
 defer src="JS/kauf.js"><?php echo '</script'; ?>
>
    <link rel="stylesheet" href="CSS/kauf.css">
</head>
<body>
    <header>
        <p onclick="window.location.href='index.php'" >Shop Name</p>
        <button id="cart-button" onclick="window.history.back()">
            <i class="fa fa-chevron-left" aria-hidden="true"></i>
        </button>
    </header>

    <main class="cart-page">
        <h2>Kaufübersicht</h2>

        <div id="warenkorb-liste">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['warenkorb']->value, 'ware');
$_smarty_tpl->tpl_vars['ware']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['ware']->value) {
$_smarty_tpl->tpl_vars['ware']->do_else = false;
?>
                <div class="cart-item" data-name="<?php echo $_smarty_tpl->tpl_vars['ware']->value['Name'];?>
" data-preis="<?php echo $_smarty_tpl->tpl_vars['ware']->value['Preis'];?>
" data-anzahl="<?php echo $_smarty_tpl->tpl_vars['ware']->value['Anzahl'];?>
">
                    <img src="Bilder/<?php echo $_smarty_tpl->tpl_vars['ware']->value['Bild'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['ware']->value['Name'];?>
">
                    <div class="cart-item-info">
                        <h3><?php echo $_smarty_tpl->tpl_vars['ware']->value['Name'];?>
</h3>
                        <p>Einzelpreis: <?php echo $_smarty_tpl->tpl_vars['ware']->value['Preis'];?>
 €</p>
                        <p>Anzahl: <?php echo $_smarty_tpl->tpl_vars['ware']->value['Anzahl'];?>
</p>
                        <p class="produkt-zwischensumme">Zwischensumme: <span></span> €</p>
                    </div>
                </div>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>

        <h3>Gesamtsumme: <span id="gesamtpreis">0.00</span> €</h3>

        <form id="kauf-formular" method="POST" action="kauf.php">
            <button type="submit" id="kaufen-button">Kaufen</button>
        </form>

        <!--button id="kaufen-button">Jetzt kaufen</button-->
    </main>
</body>

</html>
<?php }
}

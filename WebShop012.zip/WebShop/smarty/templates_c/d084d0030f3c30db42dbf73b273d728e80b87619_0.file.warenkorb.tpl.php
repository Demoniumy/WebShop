<?php
/* Smarty version 4.5.5, created on 2025-04-30 01:01:11
  from 'C:\xampp\htdocs\WebShop\smarty\templates\warenkorb.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_68115a373dbad9_55589179',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd084d0030f3c30db42dbf73b273d728e80b87619' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WebShop\\smarty\\templates\\warenkorb.tpl',
      1 => 1745967667,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:head.inc.tpl' => 1,
  ),
),false)) {
function content_68115a373dbad9_55589179 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="de">
<head>
    <?php $_smarty_tpl->_subTemplateRender("file:head.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <link rel="stylesheet" href="CSS/warenkorb.css">
</head>
<body>
    <header>
        <p onclick="window.location.href='index.php'" >Shop Name</p>

        <button id="cart-button" onclick="window.history.back()">
            <i class="fa fa-chevron-left" aria-hidden="true"></i>
        </button>

        
    </header>

    <main class="cart-page">
        <h2>Dein Warenkorb</h2>
        <?php if ($_smarty_tpl->tpl_vars['warenkorb']->value == Null) {?>

            <p style="font-size: 80px;">Warenkorb ist Leer</p>
            <a onclick="window.history.back()" style="font-size: 50px ; text-decoration: underline;">Zürück</a>
        <?php } else { ?>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['warenkorb']->value, 'ware');
$_smarty_tpl->tpl_vars['ware']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['ware']->value) {
$_smarty_tpl->tpl_vars['ware']->do_else = false;
?>
                <div class="cart-item">
                    <img src="Bilder/<?php echo $_smarty_tpl->tpl_vars['ware']->value['Bild'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['ware']->value['Name'];?>
">
                    <div class="cart-item-info">
                        <h2><?php echo $_smarty_tpl->tpl_vars['ware']->value['Name'];?>
</h2>
                        <p><?php echo $_smarty_tpl->tpl_vars['ware']->value['Preis'];?>
 €</p>
                    </div>
                    <div class="cart-item-quantity">
                        <form action="add.php" method="POST" >
                            <select name="anzahl" onchange="this.form.submit()">
                                <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? 100+1 - (0) : 0-(100)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 0, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration === 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration === $_smarty_tpl->tpl_vars['i']->total;?>
                                    <option value=<?php echo $_smarty_tpl->tpl_vars['i']->value;?>
 <?php if ($_smarty_tpl->tpl_vars['ware']->value['Anzahl'] == $_smarty_tpl->tpl_vars['i']->value) {?> selected <?php }?>> <?php echo $_smarty_tpl->tpl_vars['i']->value;?>
 </option>
                                <?php }
}
?>
                            </select>
                            <input type="hidden" name="produkt" value=<?php echo $_smarty_tpl->tpl_vars['ware']->value['ID_Produkt'];?>
>
                        </form>
                    </div>
                </div>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        

            <button onclick="window.location.href='kauf.php'">
                kaufen  
            </button>
        <?php }?>
    </main>
</body>
</html>
<?php }
}

<?php
/* Smarty version 4.5.5, created on 2025-04-29 22:17:49
  from 'C:\xampp\htdocs\WebShop\smarty\templates\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_681133ed313e53_98302961',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a7923c779239aee8cada6f0d5fb0bdd5cb2ef3b8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WebShop\\smarty\\templates\\login.tpl',
      1 => 1745781977,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_681133ed313e53_98302961 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Login - Webshop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="CSS/login.css">
</head>
<body>

    <div class="login-container">
        <h1><i class="fa fa-user-circle" aria-hidden="true"></i> Login</h1>

        <form action="login.php" method="POST">
            <label for="kennung">Kennung</label>
            <input type="kennung" name="kennung"  required>

            <label for="password">Passwort</label>
            <input type="password" name="password"  required>

            <button type="submit">Einloggen</button>

            <p class="register-link">Noch kein Konto? <a href="register.php">Registrieren</a></p>
            <a href="index.php">Zurück</a>
        </form>

        <p><?php if ((isset($_smarty_tpl->tpl_vars['error']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['error']->value;?>
 <?php }?></p>
    </div>

</body>
</html>
<?php }
}

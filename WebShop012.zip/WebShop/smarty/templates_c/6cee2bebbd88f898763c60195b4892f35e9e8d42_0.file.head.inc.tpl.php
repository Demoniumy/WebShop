<?php
/* Smarty version 4.5.5, created on 2025-04-29 22:26:02
  from 'C:\xampp\htdocs\WebShop\smarty\templates\head.inc.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_681135da182b60_10741538',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6cee2bebbd88f898763c60195b4892f35e9e8d42' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WebShop\\smarty\\templates\\head.inc.tpl',
      1 => 1745958360,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_681135da182b60_10741538 (Smarty_Internal_Template $_smarty_tpl) {
?><meta charset="UTF-8">
<title>Warenkorb</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="CSS/font-awesome-4.7.0/css/font-awesome.min.css">
<?php }
}

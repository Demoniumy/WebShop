<?php
/* Smarty version 4.5.5, created on 2025-04-29 22:16:57
  from 'C:\xampp\htdocs\WebShop\smarty\templates\anzeige.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_681133b9cd3d57_96014712',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2a53519956a1b4b681e2ff6872c4bb98228b8e95' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WebShop\\smarty\\templates\\anzeige.tpl',
      1 => 1745957816,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:head.inc.tpl' => 1,
  ),
),false)) {
function content_681133b9cd3d57_96014712 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="de">
<head>
  <title>Produktanzeige</title>
  <?php $_smarty_tpl->_subTemplateRender("file:head.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
  <link rel="stylesheet" href="CSS/anzeige.css">
</head>
<body>

<header>
  <p onclick="window.location.href='index.php'">Mein Shop</p>
  <form>
    <input type="text" placeholder="Suche nach Produkten...">
  </form>
  <button onclick="document.getElementById('warenkorb').style.display='block'">
    <i class="fa fa-shopping-basket "></i>
  </button>
</header> 

<main class="produkt-grid">
  <div class="produkt">
    <img src="Bilder/<?php echo $_smarty_tpl->tpl_vars['produkt']->value['Bild'];?>
" alt="Produktbild">
    <h2><?php echo $_smarty_tpl->tpl_vars['produkt']->value['Name'];?>
</h2>
    <p><?php echo $_smarty_tpl->tpl_vars['produkt']->value['Beschreibung'];?>
</p>
    <h3><?php echo $_smarty_tpl->tpl_vars['produkt']->value['Preis'];?>
€</h3>
  <button <?php if ((isset($_smarty_tpl->tpl_vars['kunde']->value))) {?>onclick="window.location.href='warenkorbAdd.php?pro=<?php echo $_smarty_tpl->tpl_vars['produkt']->value['ID_Produkt'];?>
'"<?php } else { ?>onclick="anmelden()"<?php }?>>In den Warenkorb</button>
  </div>
</main>

<div id="warenkorb">
    <i class="fa fa-times" onclick="warenkorb()"></i>
    <h2>Warenkorb</h2>
    <?php if (!(isset($_smarty_tpl->tpl_vars['kunde']->value))) {?>
        <p>Bitte Anmelden</p>
    <?php } else { ?>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['warenkorb']->value, 'ware');
$_smarty_tpl->tpl_vars['ware']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['ware']->value) {
$_smarty_tpl->tpl_vars['ware']->do_else = false;
?>
            <div>
                <img src="Bilder/<?php echo $_smarty_tpl->tpl_vars['ware']->value['Bild'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['ware']->value['Name'];?>
">
                <h2><?php echo $_smarty_tpl->tpl_vars['ware']->value['Name'];?>
</h2>
                <p><?php echo $_smarty_tpl->tpl_vars['ware']->value['Anzahl'];?>
</p>
            </div>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    <?php }?>
    <button onclick="window.location.href='warenkorb.php'" class="wbutton">Warenkorb</button>
</div>


  <?php echo '<script'; ?>
>
      function warenkorb() {
          const panel = document.getElementById('warenkorb');
          panel.style.display = (panel.style.display === 'block') ? 'none' : 'block';
      }
  
      function anmelden() {
          alert("Bitte anmelden");
      }
  <?php echo '</script'; ?>
>


</body>
</html>
<?php }
}

<?php

require 'defauld.inc.php';

$produktId=$_GET['id'];

$sql="SELECT * FROM Produkte WHERE ID_Produkt = :id";
$stmt=$db->prepare($sql);
$stmt->bindParam("id",$produktId,PDO::PARAM_INT);
$stmt->execute();
$produkt=$stmt->fetch();

if(isset($_SESSION['ID_Kunde']))
{
    $kunde=$_SESSION['ID_Kunde'];

    $sql="SELECT * FROM produkte p LEFT JOIN warenkorb w ON p.ID_Produkt=w.ID_Produkt WHERE w.ID_Kunde = :id";
    $stmt=$db->prepare($sql);
    $stmt->bindParam("id",$kunde);
    $stmt->execute();
    $warenkorb=$stmt->fetchAll();
}else
{
    $kunde=NULL;    
}


$smarty->assign('warenkorb',$warenkorb);
$smarty->assign('kunde',$kunde);
$smarty->assign('produkt',$produkt);
$smarty->display('anzeige.tpl');
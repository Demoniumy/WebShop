document.addEventListener("DOMContentLoaded", () => {
    const items = document.querySelectorAll(".cart-item");
    let gesamt = 0;
    let bestellText = `Bestellung vom ${new Date().toLocaleString()}\n\n`;

    items.forEach(item => {
        const name = item.dataset.name;
        const preis = parseFloat(item.dataset.preis);
        const anzahl = parseInt(item.dataset.anzahl);
        const zwischensumme = preis * anzahl;
        gesamt += zwischensumme;

        item.querySelector(".produkt-zwischensumme span").textContent = zwischensumme.toFixed(2);

        bestellText += `${name} - Einzelpreis: ${preis} € × ${anzahl} = ${zwischensumme.toFixed(2)} €\n`;
    });

    bestellText += `\nGesamtbetrag: ${gesamt.toFixed(2)} €`;

    document.getElementById("gesamtpreis").textContent = gesamt.toFixed(2);

    document.getElementById("kaufen-button").addEventListener("click", () => {
        if (confirm("Möchtest du den Kauf wirklich abschließen?")) {
            const blob = new Blob([bestellText], { type: "text/plain;charset=utf-8" });
            const link = document.createElement("a");
            const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
            link.download = `Bestellung-${timestamp}.txt`;
            link.href = URL.createObjectURL(blob);
            link.click();
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const button = document.getElementById("kaufen-button");
    if (button) {
        button.addEventListener("click", function () {
            if (confirm("Möchten Sie den Kauf wirklich abschließen?")) {
                document.getElementById("kauf-formular").submit();
            }
        });
    }
});
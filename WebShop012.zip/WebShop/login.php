<?php

require 'defauld.inc.php';

$error=NULL;

if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
    $kennung = trim($_POST['kennung'] );
    $password = trim($_POST['password']);

      
    $sql = "SELECT * FROM Kunde WHERE Kennung = :kennung";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':kennung', $kennung, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch();

    if ($user) 
    {
        if (password_verify($password, $user['Passwort'])) 
        {    
            $_SESSION['ID_Kunde']=$user['ID_Kunde'];
            
            header("Location: index.php"); 

            exit();
        }else
        {
            $error = "Falsches Passwort!";
        }
            
    } else 
    {
        $error = "Falsches Passwort!";
    }
}

$smarty->assign('error', $error);
$smarty->display('login.tpl');
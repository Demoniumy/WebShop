<?php

require 'defauld.inc.php';

$produkt=$_POST['produkt'];
$anzahl=$_POST['anzahl'];
$kunde=$_SESSION['ID_Kunde'];

if($anzahl == 0)
{
    $sql="DELETE FROM warenkorb  WHERE ID_Produkt = :idpro AND ID_Kunde=:idkun";
    $stmt=$db->prepare($sql);
    $stmt->bindParam("idpro",$produkt);
    $stmt->bindParam("idkun",$kunde);
    $stmt->execute();
}else
{
    $sql="UPDATE warenkorb SET Anzahl = :anzahl WHERE ID_Produkt = :idpro AND ID_Kunde=:idkun";
    $stmt=$db->prepare($sql);
    $stmt->bindParam("anzahl",$anzahl);
    $stmt->bindParam("idpro",$produkt);
    $stmt->bindParam("idkun",$kunde);
    $stmt->execute();
}

echo "<script type='text/javascript'>history.back();</script>";

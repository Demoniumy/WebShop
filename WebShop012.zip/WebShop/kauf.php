<?php

require 'defauld.inc.php';

if(isset($_SESSION['ID_Kunde']))
{
    $kunde=$_SESSION['ID_Kunde'];

    $sql="SELECT * FROM produkte p LEFT JOIN warenkorb w ON p.ID_Produkt=w.ID_Produkt WHERE w.ID_Kunde = :id";
    $stmt=$db->prepare($sql);
    $stmt->bindParam("id",$kunde,PDO::PARAM_INT);
    $stmt->execute();
    $warenkorb=$stmt->fetchAll();

}else
{
    $kunde=NULL;    
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
    $kunde=$_SESSION['ID_Kunde'];
    $sql="SELECT Kennung From Kunde WHERE ID_Kunde = :id";
    $stmt=$db->prepare($sql);
    $stmt->bindParam("id",$kunde,PDO::PARAM_INT);
    $stmt->execute();
    $name=$stmt->fetch();
    
    

    $sql="SELECT * FROM produkte p LEFT JOIN warenkorb w ON p.ID_Produkt=w.ID_Produkt WHERE w.ID_Kunde = :id";
    $stmt=$db->prepare($sql);
    $stmt->bindParam("id",$kunde,PDO::PARAM_INT);
    $stmt->execute();
    $warenkorb=$stmt->fetchAll();

    $timestamp = date("Y-m-d_H-i-s");
    $dateiname = $name['Kennung']."_bestellung_".$timestamp."txt";
    $pfad ='rechnung' . DIRECTORY_SEPARATOR . $dateiname;

    $gesamtpreis = 0;
    $inhalt = "Bestellung vom " . date("d.m.Y H:i") . "\n\n";

    foreach ($warenkorb as $produkt) {
        $name = $produkt['Name'];
        $anzahl = $produkt['Anzahl'];
        $preis = number_format($produkt['Preis'], 2, ',', '.');
        $zwischensumme = number_format($produkt['Preis'] * $anzahl, 2, ',', '.');
        $gesamtpreis += $produkt['Preis'] * $anzahl;

        $inhalt .= "$name\n";
        $inhalt .= "Anzahl: $anzahl\n";
        $inhalt .= "Einzelpreis: $preis €\n";
        $inhalt .= "Zwischensumme: $zwischensumme €\n";
        $inhalt .= "-------------------------\n";
    }

    $inhalt .= "\nGesamtpreis: " . number_format($gesamtpreis, 2, ',', '.') . " €\n";

    file_put_contents($pfad, $inhalt);

    $sql="INSERT INTO rechnung (pfad,ID_Kunde,name) VALUE (:pfad,:kunde,:name)";
    $stmt=$db->prepare($sql);
    $stmt->bindParam("pfad",$pfad);
    $stmt->bindParam("kunde",$kunde);
    $stmt->bindParam("name",$dateiname);
    $stmt->execute();

    $sql="DELETE FROM warenkorb  WHERE ID_Kunde=:idkun";
    $stmt=$db->prepare($sql);
    $stmt->bindParam("idkun",$kunde);
    $stmt->execute();

    header("Location: index.php");
}

$smarty->assign('warenkorb',$warenkorb);
$smarty->assign('kunde',$kunde);
$smarty->display('kauf.tpl');
